SMART PAINTING SERVICE WEBSITE - UPDATED
Main homepage: index.html
Pages: painting.html and interior-solutions.html
Logo: assets/smart-painting-logo.jpg
Custom domain: www.smartpaintingservice.in

Upload all files and the assets folder to your hosting public_html folder.
Keep index.html, painting.html and interior-solutions.html at the root.

Appointment form:
- Captures name, phone, optional referral code/name, service, preferred date/time and address.
- Sends submissions to smartpatintingservice@hotmail.com using FormSubmit.
- The mailbox owner must complete FormSubmit's first-time activation email before submissions are delivered. The email recipient is smartpatintingservice@hotmail.com.
- Email delivery depends on the FormSubmit third-party service; this ZIP does not send SMS notifications.

WhatsApp:
- Floating WhatsApp icon opens https://wa.me/916290164176.
- Contact phone updated to +91 62901 64176.

For GitHub Pages, upload all files to the repository root and set the custom domain
in Settings > Pages. Configure DNS with your domain provider and enable HTTPS.

Booking popup: appears after 25 seconds and repeats 25 seconds after it is dismissed.
Social links: Facebook and LinkedIn share the website; Instagram and YouTube open their platform homepages until official profile URLs are supplied; WhatsApp shares the website link.
Logo: updated using the latest logo image supplied by the owner.
